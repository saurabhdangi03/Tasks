package com.registrationformapi.registrationformapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegistrationformapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
