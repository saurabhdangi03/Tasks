package com.registrationformapi.registrationformapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegistrationformapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegistrationformapiApplication.class, args);
	}

}
